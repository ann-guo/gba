/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=19x38 dream images/dream.png 
 * Time-stamp: Friday 04/09/2021, 00:09:53
 * 
 * Image Information
 * -----------------
 * images/dream.png 19@38
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DREAM_H
#define DREAM_H

extern const unsigned short dreamImg[722];
#define DREAM_SIZE 1444
#define DREAM_LENGTH 722
#define DREAM_WIDTH 19
#define DREAM_HEIGHT 38

#endif

