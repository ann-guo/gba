/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --device=gba --mode=3 background2 images/background2.png 
 * Time-stamp: Friday 04/09/2021, 07:44:41
 * 
 * Image Information
 * -----------------
 * images/background2.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BACKGROUND2_H
#define BACKGROUND2_H

extern const unsigned short background2[38400];
#define BACKGROUND2_SIZE 76800
#define BACKGROUND2_LENGTH 38400
#define BACKGROUND2_WIDTH 240
#define BACKGROUND2_HEIGHT 160

#endif

