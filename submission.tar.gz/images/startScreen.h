/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --device=gba --mode=3 startScreen images/startScreen.png 
 * Time-stamp: Friday 04/09/2021, 10:48:37
 * 
 * Image Information
 * -----------------
 * images/startScreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STARTSCREEN_H
#define STARTSCREEN_H

extern const unsigned short startScreen[38400];
#define STARTSCREEN_SIZE 76800
#define STARTSCREEN_LENGTH 38400
#define STARTSCREEN_WIDTH 240
#define STARTSCREEN_HEIGHT 160

#endif

