/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=19x38 zombie images/zombie.png 
 * Time-stamp: Friday 04/09/2021, 06:16:26
 * 
 * Image Information
 * -----------------
 * images/zombie.png 19@38
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ZOMBIE_H
#define ZOMBIE_H

extern const unsigned short zombie[722];
#define ZOMBIE_SIZE 1444
#define ZOMBIE_LENGTH 722
#define ZOMBIE_WIDTH 19
#define ZOMBIE_HEIGHT 38

#endif

