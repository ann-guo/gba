Press START begin.
Press SELECT to go back to start screen.
Press RIGHT to move right.
Press LEFT to move left.
Press UP to jump.

How to Win.
Make it to the other side of the screen.

How to Lose. 
Lose all health by colliding with zombie.